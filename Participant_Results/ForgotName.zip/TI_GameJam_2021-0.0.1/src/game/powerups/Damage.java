package game.powerups;

import game.enemies.Enemy;
import game.towers.Tower;

import java.util.ArrayList;

public class Damage extends PowerUp {

    public Damage()
    {
        super("/powerups/damage.png", 10, 250, 100, 100);
        this.rechargeTime = 10;
        this.activeTime = 5;
        this.button.setRound();
    }

    @Override
    public void effect()
    {
        ArrayList<Enemy> enemies = this.game.GetEnemies();
        for(Enemy enemy : enemies)
        {
            enemy.damage(20);
        }
    }

}
