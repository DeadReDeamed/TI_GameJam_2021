package game.level;

import game.enemies.GreenGhost;
import game.enemies.RedGhost;

/**
 * Created by johan on 2017-04-10.
 */
public class Level3 extends Level {

	public Level3() {

		map = "map1.json";
		waves.add(new Wave(1, 10, RedGhost.class));
		waves.add(new Wave(0.5, 15, GreenGhost.class));
		waves.add(new Wave(1, 10, RedGhost.class));




	}
}
