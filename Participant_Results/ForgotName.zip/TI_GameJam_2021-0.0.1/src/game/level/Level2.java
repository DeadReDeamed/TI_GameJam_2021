package game.level;

import game.enemies.GreenGhost;
import game.enemies.PinkGhost;
import game.enemies.RedGhost;

/**
 * Created by johan on 2017-04-10.
 */
public class Level2 extends Level {

	public Level2() {

		map = "map1.json";
		waves.add(new Wave(1, 10, GreenGhost.class));
		waves.add(new Wave(0.5f, 5, PinkGhost.class));
		waves.add(new Wave(1f, 4, RedGhost.class));



	}
}
