package game.level;

import game.enemies.GreenGhost;
import game.enemies.RedGhost;

/**
 * Created by johan on 2017-04-10.
 */
public class Level1 extends Level {

	public Level1() {

		map = "map2.json";



		waves.add(new Wave(1, 5, GreenGhost.class));
		waves.add(new Wave(1, 3, RedGhost.class));
		waves.add(new Wave(1, 6, GreenGhost.class));




	}
}
