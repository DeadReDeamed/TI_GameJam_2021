package game.enemies;

/**
 * Created by johan on 2017-04-10.
 */
public class PinkGhost extends Enemy {

	public PinkGhost() {
		super("/enemies/pinkGhost.png");
		this.speed = 120;
		this.maxHealth = 170;
		this.gold = 25;
	}
}
