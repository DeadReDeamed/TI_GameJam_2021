package game.enemies;

/**
 * Created by johan on 2017-04-10.
 */
public class BlueGhost extends Enemy {

	public BlueGhost() {
		super("/enemies/blueGhost.png");
		this.speed = 100;
		this.maxHealth = 110;
		this.gold = 25;
	}
}
