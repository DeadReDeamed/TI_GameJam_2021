package game.enemies;

public class RedGhost extends Enemy {

    public RedGhost(){
        super("/enemies/summoner.png");
        this.speed = 75;
        this.maxHealth = 300;
        this.gold = 10;
    }
}
