package game.enemies;

/**
 * Created by johan on 2017-04-10.
 */
public class GreenGhost extends Enemy {

	public GreenGhost() {
		super("/enemies/wanderer.png");
		this.speed = 100;
		this.maxHealth = 140;
		this.gold = 25;
	}
}
