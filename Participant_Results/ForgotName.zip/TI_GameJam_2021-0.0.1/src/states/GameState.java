package states;

import game.MusicPlayer;
import ui.TowerDefence;

import java.awt.*;
import java.util.Random;

/**
 * Created by johan on 2017-04-10.
 */
public class GameState extends State {

	long lastTime = System.nanoTime();


	@Override
	public void init() {
		if (new Random().nextDouble() > 0.5){
			MusicPlayer.PlayMusic("resources\\OST\\gamejam1.wav");
		} else {
			MusicPlayer.PlayMusic("resources\\OST\\gamejam2.wav");
		}

	}

	@Override
	public State update() {
		long time = System.nanoTime();
		double elapsedTime = (time-lastTime) / 1e9;
		lastTime = time;

		towerDefence.game.update(mouseState, lastMouseState, elapsedTime);

		if((towerDefence.game.gameState == game.GameState.Winner || towerDefence.game.gameState == game.GameState.Loser) &&
			mouseState.left && !lastMouseState.left)
			return new MainMenuState();

		return null;
	}

	@Override
	public void draw(Graphics2D g2d) {
		towerDefence.game.draw(g2d);

	}
}
